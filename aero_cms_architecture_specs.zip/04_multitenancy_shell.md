# Aero.Cms Spec: Multi-Tenancy & Tenant Shell Architecture

Supports multiple websites in one deployment.

site1.com
site2.com
site3.com

Each tenant has:

content
modules
themes
users
database

## Tenant Model

```csharp
public class Tenant
{
    public string Name { get; set; }
    public string Hostname { get; set; }
    public string Database { get; set; }
}
```

## Tenant Resolver

```csharp
public class TenantResolverMiddleware
{
    public async Task Invoke(HttpContext context)
    {
        var host = context.Request.Host.Host;
    }
}
```

## Tenant Shell

```csharp
public class TenantShell
{
    public IServiceProvider ServiceProvider { get; set; }
    public RequestDelegate Pipeline { get; set; }
}
```