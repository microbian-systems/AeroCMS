# Aero.Cms Spec: UI Composition & Shape Rendering

## Overview
This document defines the UI composition system used by Aero.Cms. Modules dynamically contribute UI elements without modifying the host application.

Modules → create shapes
Themes → render shapes
Core → orchestrates placement

## Shape Model

```csharp
public class Shape
{
    public string Type { get; set; }
    public Dictionary<string, object> Properties { get; } = new();
    public List<Shape> Children { get; } = new();
}
```

Example:

Type: DashboardWidget
Title = "Recent Posts"
Count = 42

## Shape Factory

```csharp
public interface IShapeFactory
{
    Shape Create(string type);
}
```

## Layout Zones

Header
Sidebar
Content
Footer

```csharp
public class LayoutZones
{
    public List<Shape> Header { get; } = new();
    public List<Shape> Sidebar { get; } = new();
    public List<Shape> Content { get; } = new();
    public List<Shape> Footer { get; } = new();
}
```

## Shape Contributors

```csharp
public interface IShapeContributor
{
    void BuildShapes(LayoutZones zones, IShapeFactory factory);
}
```

Example:

```csharp
public class BlogDashboardShapes : IShapeContributor
{
    public void BuildShapes(LayoutZones zones, IShapeFactory factory)
    {
        var widget = factory.Create("DashboardWidget");
        widget.Properties["Title"] = "Recent Blog Posts";
        widget.Properties["Count"] = 42;
        zones.Content.Add(widget);
    }
}
```

## Rendering Shapes

Shape Type → Razor View

Example:

DashboardWidget → Views/Shapes/DashboardWidget.cshtml

## Menu Contribution

```csharp
public interface IAdminMenuContributor
{
    void BuildMenu(AdminMenuBuilder builder);
}
```