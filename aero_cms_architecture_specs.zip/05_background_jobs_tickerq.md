# Aero.Cms Spec: Distributed Background Jobs (TickerQ)

Background jobs handle:

scheduled publishing
email sending
search indexing
thumbnail generation

## Job Envelope

```csharp
public class BackgroundJobEnvelope
{
    public string Tenant { get; set; }
    public string JobType { get; set; }
    public string Payload { get; set; }
}
```

## Worker Flow

Job dequeued
Resolve tenant
Load tenant shell
Execute job

```csharp
var shell = await shellHost.GetShellAsync(job.Tenant);
using var scope = shell.ServiceProvider.CreateScope();
```