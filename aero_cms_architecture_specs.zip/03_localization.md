# Aero.Cms Spec: Localization Module

Localization implemented as a module.

Features:
language detection
culture routing
localized content
resource localization

## Module Example

```csharp
public class LocalizationModule : IModule
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddLocalization();
    }

    public void Init(WebApplication app)
    {
        app.UseRequestLocalization();
    }
}
```

## Culture Routes

/en/blog
/fr/blog
/es/blog