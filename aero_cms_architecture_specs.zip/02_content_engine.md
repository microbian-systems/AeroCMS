# Aero.Cms Spec: Dynamic Content Engine

## Overview

Content is composed dynamically.

ContentType
  └ ContentPart
       └ ContentField

Example:

BlogPost
 TitlePart
 BodyPart
 TagsPart

## Content Item

```csharp
public class ContentItem
{
    public string Id { get; set; }
    public string ContentType { get; set; }
    public Dictionary<string, object> Parts { get; set; } = new();
}
```

Example document:

{
 "contentType": "BlogPost",
 "parts": {
   "TitlePart": { "Title": "Hello World" },
   "BodyPart": { "Html": "<p>Hello world</p>" }
 }
}

## Parts

```csharp
public interface IContentPart
{
    string Name { get; }
}
```

## Fields

TextField
NumberField
DateField
MarkdownField
MediaField

## Content Type Definition

```csharp
public class ContentTypeDefinition
{
    public string Name { get; set; }
    public List<string> Parts { get; set; } = new();
}
```

## Editor Generation

foreach part in ContentType
   foreach field in part
        render editor